# Quickstart Guide for LangChain

Mostly taken from the official website: [Quickstart Guide](https://python.langchain.com/en/latest/getting_started/getting_started.html#)